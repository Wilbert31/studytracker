<?php

	date_default_timezone_set('Asia/Manila');
    $time = date('g:i a');
	$date = date("m/d/Y"); 

	
	if (isset($_POST['submit'])){
		
		$get_time = $_POST["time"];
		echo $get_time;

	}


?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

	<!-- Local CSS -->
	<link rel="stylesheet" href="css/digital_clock.css">

    <title>Study Tracker System</title>

  </head>
  <body>

<div class="container-fluid">
    <div class="jumbotron text-center">
	<h1>Study Time Tracker</h1>
	<h3 id="getDate"></h3><span id="getTime"></span>

    </div>
</div>

<div class="container">
	<div class="row">
	<!-- right first row -->
	<div class="col-sm-8 text-center bg-light">
	
	<form class="main-form" method="post">

	<p>Welcome: Gerald</p>
	<label for="inputStart">Time Start:</label>
	<input class="form-control" type="text" readonly>
	<label for="inputEnd">Time End:</label>
	<input class="form-control" type="text" readonly>

	<button class="btn btn-success m-3" name="inputStart" value="<?php $time ?>">Start</button>
	<button class="btn btn-danger m-3" name="inputEnd" value="<?php $time ?>">Stop</button> 

	<br>

	<label for="inputComment">Comments:</label>
	<textarea id="inputComment" class="form-control" rows="5" id="comment"></textarea>



	<br>
	<br>
	<button type="submit" class="btn btn-primary m-3" value="submit">Submit</button>

	</form>
	</div>
	
	<!-- left first row -->
	<div class="col-sm-4 text-center bg-dark">
	<p class="text-light">Active:</p>
	<ul class="list-group">
		<li  class="list-group-item">Gerald</li>
	</ul>
	</div>

	<div class="col-sm-12 text-center bg-light mt-3">
	<h3>History</h3>
	<table class="table">
			<thead class="thead-light">
			<tr>
				<th></th>Date</th>
				<th>Start Time</th>
				<th>End Time</th>
				<th>Duration</th>
				<th>Comments</th>
			</tr>
			</thead>
			<tbody>

			<tr>

				<td>03/01/2020</td>
				<td>4:00 PM</td>
				<td>4:30 PM</td>
				<td>30 minutes</td>
				<td> Study React States and Props</td>
			</tr>
		</tbody>
	</table>
	
	</div>

</div>



</div>



    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	
	<!-- Local JS -->
	<script src="js/digital_clock.js"></script>


	</body>
</html>