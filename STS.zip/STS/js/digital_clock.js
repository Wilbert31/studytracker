// Display Time
const myVar = setInterval(myTimer, 1000);

function myTimer() {
  const d = new Date();
  document.getElementById("getTime").innerHTML = d.toLocaleTimeString();
}

// Display Date and Day
function DateToday(date){
  const arrMonth = [' January', ' February', ' March', ' April', ' May', ' June', ' July', ' August', ' September', ' October', ' November', ' December'];
  const arrday = [' Monday', ' Tuesday', ' Wednesday', ' Thursday', ' Friday', ' Saturday', ' Sunday'];
  var d = new Date(date);
    month = d.getMonth();
    day = d.getDate();
    year = d.getFullYear();
    araw = d.getDay();
    
      return arrMonth[month] + " " + day + ", " + year + arrday[araw-1] + " " + year;
  };
  const timer = new Date();
  const date = DateToday(timer);
  
  document.getElementById('getDate').innerHTML = date;