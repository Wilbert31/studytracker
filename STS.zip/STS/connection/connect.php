<?php

    $connect = mysqli_connect("localhost", "root", "", "study_tracker");
    if (mysqli_connect_errno()) {     
        echo "Failed to connect to Mysql: " . mysql_connect_error();
}

?>